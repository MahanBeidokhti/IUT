#include <iostream>
#include <string>
#include <list>

using namespace std;

static int ID_Gen = 0;

class Person
{
protected:
    string Name, Yekta_ID;
    int ID, Age;

public:
    Person()
    {
        ID_Gen++;
        Name = "None";
        ID = ID_Gen;
        Yekta_ID = "0000";
        Age = 0;
    }
    Person(string name, string yekta_id, int age)
    {
        ID_Gen++;
        Name = name;
        ID = ID_Gen;
        Yekta_ID = yekta_id;
        Age = age;
    }

    virtual void Print() = 0;
};

class Lesson
{
protected:
    string Start_Time, End_Time, Name;

public:
    Lesson()
    {
        Start_Time = "00:00";
        End_Time = "00:00";
        Name = "None";
    }
    Lesson(string start, string end, string name)
    {
        Start_Time = start;
        End_Time = end;
        Name = name;
    }
    void time_print()
    {
        cout << Start_Time << " - " << End_Time;
    }
}

class Ostad : public Person
{
protected:
    list<Lesson> Doroos;

public:
    Ostad()
    {
        Lesson none;
        Doroos.push_front(none);
    }
    Ostad(string name, string yekta_id, int age, list<Lesson> doroos) : Person(name, yekta_id, age)
    {
        Doroos = doroos;
    }

} class Daneshjoo : public Person
{
protected:
    list<Lesson> Doroos;
    Ostad Teacher;

public:
    Daneshjoo()
    {
        Ostad temp;
        Lesson none;
        Doroos.push_front(none);
        Teacher = temp;
    }
    Daneshjoo(string name, string yekta_id, int age, list<Lesson> doroos) : Person(name, yekta_id, age)
    {
        Ostad temp;
        Teacher = temp;
        Doroos = doroos;
    }
}

int
main()
{
}